(function ($) {
    $('#accordion').accordion();
}(window.jQuery));